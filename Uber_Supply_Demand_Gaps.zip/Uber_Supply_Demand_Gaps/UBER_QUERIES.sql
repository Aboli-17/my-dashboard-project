CREATE DATABASE uber_project;
USE uber_project;

SHOW TABLES;

-- SELECT * FROM uber_cleaned_data_01 LIMIT 10;

DESCRIBE uber_cleaned_data_01;

ALTER TABLE uber_cleaned_data_01
DROP COLUMN MyUnknownColumn;

-- ===========================
-- UBER SUPPLY DEMAND GAP SQL QUERIES
-- ===========================

-- 1. Total number of requests
SELECT COUNT(*) AS total_requests
FROM uber_cleaned_data_01;

-- 2. Total completed trips
SELECT COUNT(*) AS completed_trips
FROM uber_cleaned_data_01
WHERE Status = 'Trip Completed';

-- 3. Total cancelled trips
SELECT COUNT(*) AS cancelled_trips
FROM uber_cleaned_data_01
WHERE Status = 'Cancelled';

-- 4. Total trips where no cars available
SELECT COUNT(*) AS no_cars_available
FROM uber_cleaned_data_01
WHERE Status = 'No Cars Available';

-- 5. Requests by Hour and Status
SELECT Hour,
       Status,
       COUNT(*) AS total_requests
FROM uber_cleaned_data_01
GROUP BY Hour, Status
ORDER BY Hour;

-- 6. Requests by Time Slot and Status
SELECT `Time Slot`,
       Status,
       COUNT(*) AS total_requests
FROM uber_cleaned_data_01
GROUP BY `Time Slot`, Status
ORDER BY `Time Slot`;

-- 7. Requests by Pickup Point and Status
SELECT `Pickup Point`,
       Status,
       COUNT(*) AS total_requests
FROM uber_cleaned_data_01
GROUP BY `Pickup Point`, Status
ORDER BY `Pickup Point`;

-- 8. Fulfillment rate (%) per Hour
SELECT Hour,
       COUNT(*) AS total_requests,
       SUM(CASE WHEN Status='Trip Completed' THEN 1 ELSE 0 END) AS completed_requests,
       ROUND(
         SUM(CASE WHEN Status='Trip Completed' THEN 1 ELSE 0 END) / COUNT(*) * 100, 
         2
       ) AS fulfillment_rate_percent
FROM uber_cleaned_data_01
GROUP BY Hour
ORDER BY Hour;

-- 9. Fulfillment rate (%) per Time Slot
SELECT `Time Slot`,
       COUNT(*) AS total_requests,
       SUM(CASE WHEN Status='Trip Completed' THEN 1 ELSE 0 END) AS completed_requests,
       ROUND(
         SUM(CASE WHEN Status='Trip Completed' THEN 1 ELSE 0 END) / COUNT(*) * 100,
         2
       ) AS fulfillment_rate_percent
FROM uber_cleaned_data_01
GROUP BY `Time Slot`
ORDER BY `Time Slot`;

-- 10. Busiest days of the week
SELECT `Day of Week`,
       COUNT(*) AS total_requests
FROM uber_cleaned_data_01
GROUP BY `Day of Week`
ORDER BY total_requests DESC;

-- 11. Total requests by hour
SELECT Hour, COUNT(*) AS total_requests
FROM uber_cleaned_data_01
GROUP BY Hour
ORDER BY Hour;





